var group__porting__interface =
[
    [ "sl_IfClose", "group__porting__interface.html#ga93d829306f92470614ca2fe71e7fbaa2", null ],
    [ "sl_IfMaskIntHdlr", "group__porting__interface.html#ga134a6c4658baae78724989e8a36d7be0", null ],
    [ "sl_IfOpen", "group__porting__interface.html#ga206e7c86da4e31989d54dbd8531ce505", null ],
    [ "sl_IfRead", "group__porting__interface.html#ga0d4d3db7b5ee6efcaf940de38f32d190", null ],
    [ "sl_IfRegIntHdlr", "group__porting__interface.html#ga0e17e205005322be3b619eeeeec9f069", null ],
    [ "sl_IfUnMaskIntHdlr", "group__porting__interface.html#gab3b2a3ae727a4e932ee45ea17fe4f701", null ],
    [ "sl_IfWrite", "group__porting__interface.html#gaaca4940235fc8e01cdad18a0908fda34", null ],
    [ "SL_START_WRITE_STAT", "group__porting__interface.html#gacd77caa77de50bd06faf1f5b3280255c", null ]
];