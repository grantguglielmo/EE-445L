var struct_slrx_filter_rule_header_args_and_mask__t =
[
    [ "RuleHeaderArgs", "struct_slrx_filter_rule_header_args_and_mask__t.html#abb9bde3180785cbeed7c73b5253c10ab", null ],
    [ "RuleHeaderArgsMask", "struct_slrx_filter_rule_header_args_and_mask__t.html#a56eb016bde23aa213a1b2ffdab58f45b", null ]
];