var struct_sl_sock_keepalive__t =
[
    [ "KeepaliveEnabled", "struct_sl_sock_keepalive__t.html#abc8272f5f708ea8b857c0cf71ae819e4", null ]
];