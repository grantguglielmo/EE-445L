var struct_sl_ip_leased_async__t =
[
    [ "ip_address", "struct_sl_ip_leased_async__t.html#ad859d6980f1584cd010dece0fd7c8bf8", null ],
    [ "lease_time", "struct_sl_ip_leased_async__t.html#a6c31779aceb7ec4afe78c73d50c34461", null ],
    [ "mac", "struct_sl_ip_leased_async__t.html#a0fc1ebcb690ec8426f156a7fd33e0913", null ],
    [ "padding", "struct_sl_ip_leased_async__t.html#a201aa5283495b87fc8832e9baa63aad5", null ]
];