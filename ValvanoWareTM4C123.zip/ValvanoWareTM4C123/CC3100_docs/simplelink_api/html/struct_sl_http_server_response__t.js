var struct_sl_http_server_response__t =
[
    [ "Response", "struct_sl_http_server_response__t.html#a4811ba954641420e2e9d8002fda2d634", null ],
    [ "ResponseData", "struct_sl_http_server_response__t.html#a79b6c5114e9f6da69c3113d4be87a943", null ]
];