var group__porting__capabilities =
[
    [ "SL_INC_ARG_CHECK", "group__porting__capabilities.html#gaa42d6fa27f3569e91678da37cefdd8bc", null ],
    [ "SL_INC_EXT_API", "group__porting__capabilities.html#ga4be99245edba2bfb842d8df4d09eb999", null ],
    [ "SL_INC_NET_APP_PKG", "group__porting__capabilities.html#ga7cbf8400d435a30ab34d4a2214400114", null ],
    [ "SL_INC_NET_CFG_PKG", "group__porting__capabilities.html#gacf5fb67b728e2a462af65cdf255bcf9a", null ],
    [ "SL_INC_NVMEM_PKG", "group__porting__capabilities.html#ga9188550c03f37f238eb9f30a1cbd0df0", null ],
    [ "SL_INC_SOCK_CLIENT_SIDE_API", "group__porting__capabilities.html#ga5c7e38b29356ef0962f718e0330c9856", null ],
    [ "SL_INC_SOCK_RECV_API", "group__porting__capabilities.html#gaac3f7bc7062d8af4877ad9945e0b3d18", null ],
    [ "SL_INC_SOCK_SEND_API", "group__porting__capabilities.html#gaa73df10f6f9d30adb4ab338d340ad947", null ],
    [ "SL_INC_SOCK_SERVER_SIDE_API", "group__porting__capabilities.html#gaf01455b50bce19c25ca37eef89b77557", null ],
    [ "SL_INC_SOCKET_PKG", "group__porting__capabilities.html#gabc6eb775d34a6bfdb403870731bcb2d2", null ],
    [ "SL_INC_WLAN_PKG", "group__porting__capabilities.html#gad726661ffffa2ba5ec2a07004ca7424c", null ]
];