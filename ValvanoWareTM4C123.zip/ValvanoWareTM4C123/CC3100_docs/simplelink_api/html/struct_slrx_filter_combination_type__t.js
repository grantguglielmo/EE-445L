var struct_slrx_filter_combination_type__t =
[
    [ "CombinationFilterId", "struct_slrx_filter_combination_type__t.html#a22b5805a99770fcc3ff9092f58305e2a", null ],
    [ "CombinationTypeOperator", "struct_slrx_filter_combination_type__t.html#ad3b0190bfb0627c438a9438f6810aca8", null ],
    [ "Padding", "struct_slrx_filter_combination_type__t.html#a8fd09184ea3cdbf314c929c337753b7c", null ]
];