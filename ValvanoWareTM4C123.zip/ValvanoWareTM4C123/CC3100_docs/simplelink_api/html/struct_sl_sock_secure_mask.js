var struct_sl_sock_secure_mask =
[
    [ "secureMask", "struct_sl_sock_secure_mask.html#a63694a838fbee57415a60ab9630756d1", null ]
];