var searchData=
[
  ['porting_20_2d_20capabilities_20set',['Porting - Capabilities Set',['../group__porting__capabilities.html',1,'']]],
  ['porting_20_2d_20device_20enable_2fdisable',['Porting - Device Enable/Disable',['../group__porting__enable__device.html',1,'']]],
  ['porting_20_2d_20event_20handlers',['Porting - Event Handlers',['../group__porting__events.html',1,'']]],
  ['porting_20_2d_20communication_20interface',['Porting - Communication Interface',['../group__porting__interface.html',1,'']]],
  ['porting_20_2d_20memory_20management',['Porting - Memory Management',['../group__porting__mem__mgm.html',1,'']]],
  ['porting_20_2d_20operating_20system',['Porting - Operating System',['../group__porting__os.html',1,'']]],
  ['porting_20_2d_20user_20include_20files',['Porting - User Include Files',['../group__porting__user__include.html',1,'']]]
];
