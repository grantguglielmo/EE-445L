var union_sl_net_app_event_data__u =
[
    [ "ipAcquiredV4", "union_sl_net_app_event_data__u.html#a70e52a1e4d3f9d2f266678ec36368c7c", null ],
    [ "ipAcquiredV6", "union_sl_net_app_event_data__u.html#a400e2b41a0f0b2c5bcea239044bc9c51", null ],
    [ "ipLeased", "union_sl_net_app_event_data__u.html#aed0298fb2bc398113623878895eaa5c1", null ],
    [ "ipReleased", "union_sl_net_app_event_data__u.html#a1243613fce8b1dcb1bb980e16b18a603", null ],
    [ "sd", "union_sl_net_app_event_data__u.html#a06b0afe769d54ae94259d8532bc878b0", null ]
];