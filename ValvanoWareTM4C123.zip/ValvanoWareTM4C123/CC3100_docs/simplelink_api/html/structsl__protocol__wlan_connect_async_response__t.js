var structsl__protocol__wlan_connect_async_response__t =
[
    [ "bssid", "group__wlan.html#gafe5aa2d29b976557a88eab996244aedc", null ],
    [ "connection_type", "group__wlan.html#ga6173247e0adaa2b1a8e4cf0b338cb826", null ],
    [ "go_peer_device_name", "group__wlan.html#ga40f12accd1196f2ac05d3511c4ed49c7", null ],
    [ "go_peer_device_name_len", "group__wlan.html#ga37da28c0a7da334948501d79c9d903cb", null ],
    [ "padding", "group__wlan.html#ga9753c7c72915aa208119266b2338ea10", null ],
    [ "reason_code", "group__wlan.html#gaeb11e431f2cddfaebd37e8739263d647", null ],
    [ "ssid_len", "group__wlan.html#ga340f18f235799c8c8b592c782ef1c079", null ],
    [ "ssid_name", "group__wlan.html#ga6fd6d9217a47e240b9d454860ed8511b", null ]
];