var struct_sl_wlan_event__t =
[
    [ "Event", "group__wlan.html#ga82b85c0f983cb4be38dde9fba5968f46", null ],
    [ "EventData", "group__wlan.html#gae587c51197255d4e4ef20cc90d73825f", null ]
];