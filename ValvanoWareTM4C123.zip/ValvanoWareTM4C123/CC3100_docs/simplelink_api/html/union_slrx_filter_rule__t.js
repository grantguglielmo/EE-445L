var union_slrx_filter_rule__t =
[
    [ "CombinationType", "union_slrx_filter_rule__t.html#a80b200ae0cf46a6badfb2e62392d2b0c", null ],
    [ "HeaderType", "union_slrx_filter_rule__t.html#a6d946e0ff1c4c0cd939e209a4582bf85", null ],
    [ "PayLoadHeaderType", "union_slrx_filter_rule__t.html#a936ba6e8ff6ba17047db77545e716ad2", null ]
];