var structsl__protocol___info_element__t =
[
    [ "data", "group__wlan.html#gae5c081c43ad642766eefaf6219ad9588", null ],
    [ "id", "group__wlan.html#ga35fc2aadb5f638d5cc76810431d956c7", null ],
    [ "length", "group__wlan.html#ga92fb67cb6d873cedc8c09a2d901396a2", null ],
    [ "oui", "group__wlan.html#gaac7520636fd1fb014683185c68890314", null ]
];