var struct_sl_sock_event__t =
[
    [ "Event", "struct_sl_sock_event__t.html#a82b85c0f983cb4be38dde9fba5968f46", null ],
    [ "EventData", "struct_sl_sock_event__t.html#a3b2d881ad4bcc5cee8a09ea2e3a9e364", null ]
];