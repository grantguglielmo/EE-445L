var struct_sl_version_full =
[
    [ "ChipFwAndPhyVersion", "struct_sl_version_full.html#ad5ea7f4ad7fbeb5a94ac66e2da5d55db", null ],
    [ "NwpVersion", "struct_sl_version_full.html#a5a70ba14a5875f551c2c7ae801fb1335", null ],
    [ "Padding", "struct_sl_version_full.html#af523079e63d97b8e9ac4a4ec3945b4e8", null ],
    [ "RomVersion", "struct_sl_version_full.html#a262ad6b445372302a6cbde24289b3e71", null ]
];