var structsl___device_report =
[
    [ "sender", "structsl___device_report.html#ac0b67f727ab542ea92d7bb5a9586c638", null ],
    [ "status", "structsl___device_report.html#a62a30cfd97a8f9722bf1d599d3bf4d4b", null ]
];