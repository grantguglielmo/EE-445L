var struct___sl_partial_version =
[
    [ "ChipId", "struct___sl_partial_version.html#a14a2e6d5462555db082220ebb85a29c7", null ],
    [ "FwVersion", "struct___sl_partial_version.html#a98736919e35ab730d0ce2b6fc1e6120d", null ],
    [ "PhyVersion", "struct___sl_partial_version.html#a33f4c8d014f14eaeabd5972e825529b2", null ]
];