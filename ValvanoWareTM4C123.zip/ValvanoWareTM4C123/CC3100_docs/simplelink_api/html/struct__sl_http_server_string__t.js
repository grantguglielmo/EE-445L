var struct__sl_http_server_string__t =
[
    [ "data", "struct__sl_http_server_string__t.html#ac24cea2bfcc927fd29bc74d1086707d8", null ],
    [ "len", "struct__sl_http_server_string__t.html#a8bb3e1dd5fd30402c69fd8a9f7dd0950", null ]
];