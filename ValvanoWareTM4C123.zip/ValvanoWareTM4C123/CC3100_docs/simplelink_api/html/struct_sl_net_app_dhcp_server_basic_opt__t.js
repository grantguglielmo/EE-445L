var struct_sl_net_app_dhcp_server_basic_opt__t =
[
    [ "ipv4_addr_last", "struct_sl_net_app_dhcp_server_basic_opt__t.html#aff28c350f6cfc52cca697a13f09fa686", null ],
    [ "ipv4_addr_start", "struct_sl_net_app_dhcp_server_basic_opt__t.html#a38a64996f130fc91c69156c6e4e8a930", null ],
    [ "lease_time", "struct_sl_net_app_dhcp_server_basic_opt__t.html#a6c31779aceb7ec4afe78c73d50c34461", null ]
];