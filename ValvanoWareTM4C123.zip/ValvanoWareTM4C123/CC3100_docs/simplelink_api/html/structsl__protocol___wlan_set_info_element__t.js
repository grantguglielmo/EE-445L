var structsl__protocol___wlan_set_info_element__t =
[
    [ "ie", "group__wlan.html#gac1029492d0e3b06663e3dfa879773e2a", null ],
    [ "index", "group__wlan.html#ga5abc5420a7f15af7410173395b610ea8", null ],
    [ "role", "group__wlan.html#gabd416002fb5c1d79fddbb76916d343be", null ]
];