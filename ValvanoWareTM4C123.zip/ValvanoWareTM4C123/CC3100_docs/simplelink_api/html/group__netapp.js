var group__netapp =
[
    [ "sl_NetAppDnsGetHostByName", "group__netapp.html#gaad05a467be003ce1134948a3b0497ae1", null ],
    [ "sl_NetAppDnsGetHostByService", "group__netapp.html#ga1982561dc5e1620bfc82b931346672d8", null ],
    [ "sl_NetAppGet", "group__netapp.html#gaf1784b96366deb96586b8bc1b4aa106b", null ],
    [ "sl_NetAppGetServiceList", "group__netapp.html#ga8160ab588fc70e0f8cb36c9960b03f17", null ],
    [ "sl_NetAppMDNSRegisterService", "group__netapp.html#ga4ad8fdbe9c96046b7d2631ced0cc57c4", null ],
    [ "sl_NetAppMDNSUnRegisterService", "group__netapp.html#gafabd7ec91e14727ea8a1558387b2186d", null ],
    [ "sl_NetAppPingStart", "group__netapp.html#gabd49d1043692883876c486ea89808e29", null ],
    [ "sl_NetAppSet", "group__netapp.html#gaa43539cdea03264c0a92ed29c31752fb", null ],
    [ "sl_NetAppStart", "group__netapp.html#ga6e68c4c50b5a660b23c6c67a0baf6d23", null ],
    [ "sl_NetAppStop", "group__netapp.html#ga27e4b1da87ea024e41f142773d07231a", null ]
];