var struct_sl_net_app_event__t =
[
    [ "Event", "struct_sl_net_app_event__t.html#a82b85c0f983cb4be38dde9fba5968f46", null ],
    [ "EventData", "struct_sl_net_app_event__t.html#ac58cdb6e0d008f951c65fade86f32713", null ]
];