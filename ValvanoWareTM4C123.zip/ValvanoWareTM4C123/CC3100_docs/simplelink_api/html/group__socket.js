var group__socket =
[
    [ "sl_Accept", "group__socket.html#ga70d8c15542e4590d80cc9f9283f4b210", null ],
    [ "sl_Bind", "group__socket.html#ga45b5395b4b2bdd6189998849537c7d86", null ],
    [ "sl_Close", "group__socket.html#gabc776f15d8e8d8a4662269dac8aca1fc", null ],
    [ "sl_Connect", "group__socket.html#ga2cc00ba87f0cd7cbdbfca14394502a15", null ],
    [ "SL_FD_CLR", "group__socket.html#gac2a4253cf994b2a796f730468abbe183", null ],
    [ "SL_FD_ISSET", "group__socket.html#ga4de8eef8d39b4398d2e694dc88edd64e", null ],
    [ "SL_FD_SET", "group__socket.html#ga25d4421250534b9bd4ac41b30f9cf06b", null ],
    [ "SL_FD_ZERO", "group__socket.html#gac58eca56e2cf9bf58f8f3ef8790f7740", null ],
    [ "sl_GetSockOpt", "group__socket.html#ga43f04e75d9ea0a29b4a4c58f29cfdd8c", null ],
    [ "sl_Htonl", "group__socket.html#ga56e74657a9772b9ad9e5ac5697d10562", null ],
    [ "sl_Htons", "group__socket.html#gada8288bc08f38860bd27cd5fd611e1ba", null ],
    [ "sl_Listen", "group__socket.html#ga74ea071794a86d677212d6ae5041b923", null ],
    [ "sl_Recv", "group__socket.html#ga34256a8387b64d696c4a62ac1e282ee3", null ],
    [ "sl_RecvFrom", "group__socket.html#gaee942befd4fa36fdacab25adfba2434b", null ],
    [ "sl_Select", "group__socket.html#ga0f5927fc693b19f6c1aab3110adc64b1", null ],
    [ "sl_Send", "group__socket.html#ga24dfb00de85356d4ba18662177c2eec5", null ],
    [ "sl_SendTo", "group__socket.html#ga0936b748a4f6d7f1943920ec91a82120", null ],
    [ "sl_SetSockOpt", "group__socket.html#ga173062c9a3a1ca728e651e98aedca7fb", null ],
    [ "sl_Socket", "group__socket.html#ga4808ad2f0d41a2b38b3d753ce3b3dfe9", null ]
];