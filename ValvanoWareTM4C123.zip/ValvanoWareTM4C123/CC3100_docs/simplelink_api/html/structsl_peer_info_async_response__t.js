var structsl_peer_info_async_response__t =
[
    [ "go_peer_device_name", "group__wlan.html#ga40f12accd1196f2ac05d3511c4ed49c7", null ],
    [ "go_peer_device_name_len", "group__wlan.html#ga37da28c0a7da334948501d79c9d903cb", null ],
    [ "mac", "group__wlan.html#ga0fc1ebcb690ec8426f156a7fd33e0913", null ],
    [ "own_ssid", "group__wlan.html#ga4ece6807aa2ca2a602290b8a6572f3dc", null ],
    [ "own_ssid_len", "group__wlan.html#ga54cb050f627df75b2b9deda10be8a4f6", null ],
    [ "padding", "group__wlan.html#ga351940bc24af2f72269743e35b9a32c4", null ],
    [ "wps_dev_password_id", "group__wlan.html#ga531d4129dd6d5f9fe242faa30d04c45c", null ]
];